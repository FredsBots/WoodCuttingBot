# FredsBots
# The Coordinates program is optional
# This is going to be the collection of bots im going to code using python which as as listed so far:
# 1. Woodcutting Bot 
